(function(){
    
	$('.win_wrap, .win_back').show();
})();
