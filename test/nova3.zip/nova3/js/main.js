$(function(){

	//步骤
	$(".nav a").click(function(){
		$(this).addClass('active');
		$(this).siblings().removeClass('active');
	});

	navSwiper = new Swiper('.swiper-nav', {
		speed:500,
		slidesPerView: 'auto',
        freeMode: true,
        slideToClickedSlide:true
	});
  
  console.log(navSwiper.activeIndex);

	//上传照片
	$(".upload-step").click(function(){
        $(".swiper-cover").hide();
		$(".upload-btn-2").show();
		$(".upload-btn-2").siblings().hide();
	});

    $(".upload-btn").click(function(){
        var imgSrc = "res/01.jpg"; //上传图片路径
        $("#imgSrc").attr("src",imgSrc);
        
        $(".photo>div").addClass('pinch-zoom');   
        $('div.pinch-zoom').each(function () {
              new RTP.PinchZoom($(this), {});
        });
        $(".photo").show();
    });


	//封面
	$(".cover-step").click(function(){
		$(".swiper-cover").show();
		$(".cover-tabs").show();
		$(".cover-tabs").siblings().hide();
	});

	var coverSwiper = new Swiper('.swiper-cover', {
		speed:500,
		observer:true,
		onSlideChangeStart: function(swiper){
	      $(".cover-tabs .active").removeClass('active')
	      $(".cover-tabs a").eq(swiper.activeIndex).addClass('active')  
	    }

	});

    $(".cover-tabs a").on('click', function(e) {
        e.preventDefault()
        $(".cover-tabs .active").removeClass('active')
        $(this).addClass('active')
        coverSwiper.slideTo($(this).index())
    });

    //名字
    $(".name-fill").click(function(){
        $(".t-name").focus();
    	$(".name-textarea").slideDown();
    	$(".bottom-wrapper .name-fill").show();
    	$(".bottom-wrapper .name-fill").siblings().hide();
    });

    $(".nav a").bind("click",function(e){           
        if($(e.target).closest(".name-fill").length == 0 && $(e.target).closest("#open").length == 0){            
			$(".name-textarea").slideUp();
        }
    });

    $(".name-textarea .sure").click(function(){
    	$(".name-textarea").slideUp();
    	var name = $("#t-name").val();
    	$(".name-text").text(name);
        $("#b-name").html(name);
    });

    //主题
    $(".theme-fill").click(function(){
    	$(".theme-textarea").slideDown();
    	$(".bottom-wrapper .theme-fill").show();
    	$(".bottom-wrapper .theme-fill").siblings().hide();
    });

    $(".nav a").bind("click",function(e){           
        if($(e.target).closest(".theme-fill").length == 0 && $(e.target).closest("#open").length == 0){            
			$(".theme-textarea").slideUp();
        }
    });

    $(".theme-textarea .sure").click(function(){
    	$(".theme-textarea").slideUp();
    	var theme = $("#t-theme").val();
    	$(".theme-text").text(theme);
        $("#b-theme").html(theme);
    });

    //保存分享
    $(".save-step").click(function(){
    	$(".bottom-wrapper .save-tip").show();
    	$(".bottom-wrapper .save-tip").siblings().hide();
        $(".poster-wrap").show();
        
        
        draw(src, 12341, $("#t-name").val(), $("#t-theme").val());
        
        
        $(".make-wrap").hide();
    });

    $(".nav a").bind("click",function(e){           
        if($(e.target).closest(".save-step").length == 0 && $(e.target).closest("#open").length == 0){                 
            $(".upload-wrap").show();
            $(".make-wrap").show();
            $(".poster-wrap").hide();
        }
    });



});