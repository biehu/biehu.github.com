﻿<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1.0, maximum-scale=1.0"/>
    <meta http-equiv="Content-Type" content="text/html;charset=UTF-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"/>
    <title>nova3 海报级自拍</title>
    <meta name="format-detection" content="telephone=no" />
    <meta content="" name="description">
    <meta content="" name="keywords">   
    <script src="js/jquery-1.11.0.min.js"></script> 
    <link rel="stylesheet" type="text/css" href="css/default.css" />
</head>
<body class="index-body">

<?php
        //数字输出网页计数器
        $CounterFile = "counter.dat";
        if(!file_exists($CounterFile)){        //如果计数器文件不存在
            $counter = 0;                  
            $cf = fopen($CounterFile,"w");  //打开文件
            fputs($cf,'0');                    //初始化计数器
            fclose($cf);                   //关闭文件
        }
        else{                                       //取回当前计数器的值
            $cf = fopen($CounterFile,"r");
            $counter = trim(fgets($cf));
            fclose($cf);
        }
        $counter++;                                    //计数器加一
        $cf = fopen($CounterFile,"w");              //写入新的数据
        fputs($cf,$counter);
        fclose($cf);
    ?>
<section class="content">
<!-- 内容开始 -->
   <div class="index-main">
        <div class="index-qian"><img src="images/001.jpg" alt=""></div>
        <div class="nova-title">
            <img src="images/001-1.png" alt="" class="img-1">
            <img src="images/001-1-2.png" alt="" class="img img-2">
            <img src="images/001-1-3.png" alt="" class="img img-3">
            <img src="images/001-1-4.png" alt="" class="img img-4">
            <img src="images/001-1-5.png" alt="" class="img img-5">
            <img src="images/001-1-6.png" alt="" class="img img-6">
            <img src="images/001-2.png" alt="" class="heart-1">
            <img src="images/001-3.png" alt="" class="heart-2">
        </div>
        <a href="make.html?count=<?php
             echo $counter;                            //输出计数器
            ?>" class="make-btn">
            <img src="images/001-4.png" alt="">
        </a>
        <p class="sign">已有<span class="peoples"><?php
             echo $counter;                            //输出计数器
            ?></span>位千纸鹤打卡</p>



   </div>

  
<!-- 内容结束 -->
</section>  
<script>
    $(function(){
   
    });
</script>

</body>
</html>